const skillCategories = [
  {
    title: "Technical Skills",
    skills: ["Agile", "Product Development", "Strategic Thinking", "Market Research", "Analytics", "User Design"],
  },
  {
    title: "Leadership & Communication",
    skills: ["Teamwork", "Competitive Analysis", "Google Analytics", "Risk Management", "Stakeholder Management"],
  },
  {
    title: "Tools & Certifications",
    skills: ["JIRA", "Confluence", "Trello", "Asana", "Notion", "PSPO Certified"],
  },
]

export function SkillsSection() {
  return (
    <section id="skills" className="py-20 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Expertise</p>
          <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground">Skills & Tools</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {skillCategories.map((category) => (
            <div key={category.title} className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-6">{category.title}</h3>
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1.5 bg-muted text-muted-foreground text-sm rounded-md hover:bg-primary hover:text-primary-foreground transition-colors cursor-default font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
