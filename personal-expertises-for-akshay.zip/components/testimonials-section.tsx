import { Quote, Star } from "lucide-react"

const testimonials = [
  {
    name: "Anurag",
    text: "It was a very insightful session and I came to know what is important for the interview. Thanks for the resources. The friendly nature of Akshay was great.",
    time: "1 year ago",
  },
  {
    name: "Prabhakaran",
    text: "He listens about our background and experience and suggests what are the things it takes to reach there. He has a structured plan for people interested to learn based on their knowledge levels.",
    time: "1 year ago",
  },
  {
    name: "Sheetal Choudhary",
    text: "Akshay explained everything in a very clear and planned manner. He addressed all my doubts and concerns. I would highly recommend others to get his mentorship.",
    time: "1 year ago",
  },
  {
    name: "K Akhil",
    text: "Akshay was crystal clear with approach, identified right goals that are progressive and that would set stage for long-term value add. Looking forward to working with Akshay as mentor.",
    time: "2 years ago",
  },
]

export function TestimonialsSection() {
  return (
    <section id="testimonials" className="py-20 px-6 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Testimonials</p>
          <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground mb-4">What Mentees Say</h2>
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} size={20} className="fill-primary text-primary" />
              ))}
            </div>
            <span className="text-foreground font-semibold">5.0</span>
            <span>from 29 reviews</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow">
              <Quote className="text-primary/20 mb-4" size={32} />
              <p className="text-muted-foreground leading-relaxed mb-6 italic">"{testimonial.text}"</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <span className="text-primary font-semibold text-sm">{testimonial.name.charAt(0)}</span>
                  </div>
                  <span className="font-semibold text-foreground">{testimonial.name}</span>
                </div>
                <span className="text-sm text-muted-foreground">{testimonial.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
