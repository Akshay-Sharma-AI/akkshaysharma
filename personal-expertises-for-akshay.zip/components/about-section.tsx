import { MapPin, Languages, Target } from "lucide-react"

export function AboutSection() {
  return (
    <section id="about" className="py-20 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Left - Section Title */}
          <div>
            <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">About</p>
            <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground mb-4">Who I Am</h2>
            <div className="h-1 w-16 bg-primary" />
          </div>

          {/* Right - Content */}
          <div className="lg:col-span-2 space-y-6">
            <p className="text-lg text-muted-foreground leading-relaxed">
              I'm a Senior AI and Data Product Manager at{" "}
              <span className="text-foreground font-semibold">Microsoft</span>, with previous experience at{" "}
              <span className="text-foreground font-semibold">EY</span>,{" "}
              <span className="text-foreground font-semibold">Larsen & Toubro</span>, and{" "}
              <span className="text-foreground font-semibold">Bosch</span>. I hold an MBA from{" "}
              <span className="text-foreground font-semibold">IIM Kozhikode</span> and have built my career at the
              intersection of technology, strategy, and product development.
            </p>

            <p className="text-muted-foreground leading-relaxed">
              With over 20,000 followers on professional networks and experience as a Course Creator at Unstop, I am
              passionate about sharing knowledge and helping others achieve their career goals. My approach combines
              structured planning, mock interviews, and personalized resources tailored to top companies.
            </p>

            <div className="grid sm:grid-cols-3 gap-6 pt-6">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-md bg-muted">
                  <MapPin className="text-primary" size={20} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">Location</p>
                  <p className="text-sm text-muted-foreground">Telangana, India</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-md bg-muted">
                  <Languages className="text-primary" size={20} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">Languages</p>
                  <p className="text-sm text-muted-foreground">English, Hindi, Telugu</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="p-2 rounded-md bg-muted">
                  <Target className="text-primary" size={20} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">Focus</p>
                  <p className="text-sm text-muted-foreground">AI/ML, Data Products</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
