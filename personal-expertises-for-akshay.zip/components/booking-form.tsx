"use client"

import { useState } from "react"
import { submitBookingRequest } from "@/app/actions/leads"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, CheckCircle, Loader2 } from "lucide-react"

export function BookingForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  async function handleSubmit(formData: FormData) {
    setStatus("loading")
    setErrorMessage("")

    const result = await submitBookingRequest(formData)

    if (result.success) {
      setStatus("success")
    } else {
      setStatus("error")
      setErrorMessage(result.error || "Something went wrong")
    }
  }

  if (status === "success") {
    return (
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Request Submitted!</h3>
        <p className="text-muted-foreground mb-4">
          Thank you for your interest. I'll review your request and get back to you within 24 hours.
        </p>
        <a
          href="https://cal.com/akkshay-sharma/15min"
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 text-primary hover:underline"
        >
          <Calendar className="w-4 h-4" />
          Or book a slot directly on my calendar
        </a>
      </div>
    )
  }

  return (
    <form action={handleSubmit} className="bg-card border border-border rounded-lg p-6 space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="booking-name">Name *</Label>
          <Input id="booking-name" name="name" placeholder="Your name" required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="booking-email">Email *</Label>
          <Input id="booking-email" name="email" type="email" placeholder="you@example.com" required />
        </div>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="booking-phone">Phone (optional)</Label>
          <Input id="booking-phone" name="phone" type="tel" placeholder="+91 98765 43210" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="interest">Area of Interest</Label>
          <Select name="interest">
            <SelectTrigger>
              <SelectValue placeholder="Select an area" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="product-management">Product Management</SelectItem>
              <SelectItem value="ai-ml">AI/ML & Data Science</SelectItem>
              <SelectItem value="career-transition">Career Transition</SelectItem>
              <SelectItem value="interview-prep">Interview Preparation</SelectItem>
              <SelectItem value="leadership">Leadership & Strategy</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="space-y-2">
        <Label htmlFor="experience_level">Experience Level</Label>
        <Select name="experience_level">
          <SelectTrigger>
            <SelectValue placeholder="Select your level" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="student">Student / Fresh Graduate</SelectItem>
            <SelectItem value="early">Early Career (0-3 years)</SelectItem>
            <SelectItem value="mid">Mid Career (3-7 years)</SelectItem>
            <SelectItem value="senior">Senior (7+ years)</SelectItem>
            <SelectItem value="executive">Executive / Leadership</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="booking-message">Tell me about your goals (optional)</Label>
        <Textarea
          id="booking-message"
          name="message"
          placeholder="What would you like to achieve through mentorship?"
          rows={3}
        />
      </div>

      {status === "error" && <p className="text-sm text-red-600">{errorMessage}</p>}

      <Button type="submit" className="w-full" disabled={status === "loading"}>
        {status === "loading" ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Submitting...
          </>
        ) : (
          <>
            <Calendar className="w-4 h-4 mr-2" />
            Request Mentorship Session
          </>
        )}
      </Button>
    </form>
  )
}
