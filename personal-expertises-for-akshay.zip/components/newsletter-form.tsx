"use client"

import { useState } from "react"
import { subscribeNewsletter } from "@/app/actions/leads"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { CheckCircle, Loader2, Mail } from "lucide-react"

export function NewsletterForm() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [errorMessage, setErrorMessage] = useState("")

  async function handleSubmit(formData: FormData) {
    setStatus("loading")
    setErrorMessage("")

    const result = await subscribeNewsletter(formData)

    if (result.success) {
      setStatus("success")
    } else {
      setStatus("error")
      setErrorMessage(result.error || "Something went wrong")
    }
  }

  if (status === "success") {
    return (
      <div className="flex items-center gap-2 text-green-600">
        <CheckCircle className="w-5 h-5" />
        <span className="text-sm font-medium">You're subscribed!</span>
      </div>
    )
  }

  return (
    <form action={handleSubmit} className="flex flex-col sm:flex-row gap-2">
      <Input name="email" type="email" placeholder="Enter your email" required className="flex-1" />
      <Button type="submit" disabled={status === "loading"}>
        {status === "loading" ? (
          <Loader2 className="w-4 h-4 animate-spin" />
        ) : (
          <>
            <Mail className="w-4 h-4 mr-2" />
            Subscribe
          </>
        )}
      </Button>
      {status === "error" && <p className="text-sm text-red-600 sm:absolute sm:mt-12">{errorMessage}</p>}
    </form>
  )
}
