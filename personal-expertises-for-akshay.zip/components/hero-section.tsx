import { ArrowRight, Linkedin, Mail } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="min-h-screen flex items-center pt-20 pb-12 px-6 bg-background">
      <div className="max-w-6xl mx-auto w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Text */}
          <div className="space-y-8">
            <div className="space-y-4">
              <p className="text-primary font-medium tracking-widest uppercase text-xs">
                Senior AI & Data Product Manager
              </p>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-serif font-semibold text-foreground leading-tight text-balance">
                Akkshay Sharma
              </h1>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
                Building AI-powered products at <span className="text-foreground font-semibold">Microsoft</span>.
                Transforming careers through mentorship with{" "}
                <span className="text-primary font-semibold">10+ years</span> of industry experience.
              </p>
            </div>

            <p className="text-muted-foreground leading-relaxed max-w-lg">
              I am committed to being your mentor until you achieve your dream job. Mentored 1000+ professionals and
              helped 100+ transition to Product and Consulting domains.
            </p>

            <div className="flex flex-wrap gap-4">
              <a
                href="https://cal.com/akkshay-sharma/15min"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors"
              >
                Start Your Journey
                <ArrowRight size={18} />
              </a>
              <div className="flex items-center gap-3">
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-md border border-border text-muted-foreground hover:text-primary hover:border-primary transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin size={20} />
                </a>
                <a
                  href="mailto:contact@akkshay.com"
                  className="p-3 rounded-md border border-border text-muted-foreground hover:text-primary hover:border-primary transition-colors"
                  aria-label="Email"
                >
                  <Mail size={20} />
                </a>
              </div>
            </div>

            {/* Company Logos */}
            <div className="pt-6 border-t border-border">
              <p className="text-xs text-muted-foreground uppercase tracking-widest mb-4">
                Trusted by professionals from
              </p>
              <div className="flex flex-wrap items-center gap-6">
                {["Microsoft", "EY", "L&T", "Bosch", "ADP"].map((company) => (
                  <span key={company} className="text-sm font-semibold text-muted-foreground">
                    {company}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="relative">
            <div className="relative aspect-[3/4] max-w-md mx-auto lg:max-w-none">
              <div className="relative bg-muted rounded-lg overflow-hidden border border-border shadow-lg h-full">
                <Image
                  src="/images/akkshay-sharma.png"
                  alt="Akkshay Sharma - Senior AI & Data Product Manager at Microsoft"
                  width={500}
                  height={667}
                  className="w-full h-full object-cover object-top"
                  priority
                />
              </div>
            </div>

            {/* Floating Badge */}
            <div className="absolute -bottom-4 -left-4 lg:bottom-8 lg:-left-8 bg-card border border-border rounded-lg p-4 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <span className="text-primary font-bold text-sm">IIM</span>
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">IIM Kozhikode</p>
                  <p className="text-xs text-muted-foreground">MBA Alumni</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
