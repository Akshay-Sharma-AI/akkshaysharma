import { Users, Clock, Star, Award } from "lucide-react"

const stats = [
  {
    icon: Users,
    value: "130+",
    label: "Mentees",
    description: "Professionals guided",
  },
  {
    icon: Clock,
    value: "21,000+",
    label: "Minutes",
    description: "Of mentoring time",
  },
  {
    icon: Star,
    value: "5.0",
    label: "Rating",
    description: "From 29 reviews",
  },
  {
    icon: Award,
    value: "10+",
    label: "Years",
    description: "Industry experience",
  },
]

export function StatsSection() {
  return (
    <section className="py-16 px-6 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-card border border-border rounded-lg p-6 text-center hover:shadow-md transition-shadow"
            >
              <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <stat.icon className="text-primary" size={24} />
              </div>
              <p className="text-3xl lg:text-4xl font-serif font-semibold text-foreground mb-1">{stat.value}</p>
              <p className="text-sm font-semibold text-foreground mb-1">{stat.label}</p>
              <p className="text-xs text-muted-foreground">{stat.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
