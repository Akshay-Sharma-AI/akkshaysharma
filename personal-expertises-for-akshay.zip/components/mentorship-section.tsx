import { Check, Rocket, GraduationCap, Briefcase } from "lucide-react"

const offerings = [
  "Personalized weekly plans tailored to your goals",
  "Mock interviews with feedback from industry experts",
  "Resources and materials from top companies",
  "1:1 sessions for doubt clearing",
  "Resume and profile optimization",
  "Long-term mentorship until you succeed",
]

const targetAudience = [
  {
    icon: Rocket,
    title: "Working Professionals",
    description: "Looking to transition to Product Management",
  },
  {
    icon: GraduationCap,
    title: "Freshers",
    description: "Aspiring to start a career in PM",
  },
  {
    icon: Briefcase,
    title: "Business Analysts",
    description: "Wanting to move to product roles",
  },
]

export function MentorshipSection() {
  return (
    <section id="mentorship" className="py-20 px-6 bg-background">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Mentorship Program</p>
          <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground mb-4">Your Path to Success</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            A structured, personalized approach to help you achieve your dream job in Product Management, Business
            Analysis, or Consulting.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* What You Get */}
          <div className="bg-card border border-border rounded-lg p-8">
            <h3 className="text-xl font-semibold text-foreground mb-6">What You Get</h3>
            <ul className="space-y-4">
              {offerings.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="p-1 rounded-full bg-primary/10 mt-0.5">
                    <Check className="text-primary" size={14} />
                  </div>
                  <span className="text-muted-foreground">{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Who Can Join */}
          <div className="space-y-6">
            <h3 className="text-xl font-semibold text-foreground">Who Can Join</h3>
            <div className="space-y-4">
              {targetAudience.map((item, index) => (
                <div
                  key={index}
                  className="bg-card border border-border rounded-lg p-5 flex items-start gap-4 hover:shadow-md transition-shadow"
                >
                  <div className="p-3 rounded-md bg-muted">
                    <item.icon className="text-primary" size={24} />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground">{item.title}</h4>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
