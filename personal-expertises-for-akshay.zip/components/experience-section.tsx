const experiences = [
  {
    role: "Senior AI & Data Product Manager",
    company: "Avalara",
    period: "Mar 2025 — Present",
    description:
      "Leading AI-first product strategy for Managed Compliance Platform, embedding real-time fraud detection and compliance tracking for global enterprises.",
    current: true,
  },
  {
    role: "AI Platform Product Manager",
    company: "NSL (Brane AI) Enterprises",
    period: "May 2023 — Mar 2025",
    description:
      "Led development of AI-powered B2B SaaS platform for financial risk management, achieving 30% increase in customer adoption.",
    current: false,
  },
  {
    role: "Data and AI Product Manager",
    company: "Microsoft",
    period: "Feb 2022 — Apr 2023",
    description:
      "Owned end-to-end development of Azure Cloud Migration Tool, delivering 25% improvement in forecast accuracy and 20% reduction in decision-making time.",
    current: false,
  },
  {
    role: "Product Manager",
    company: "Ernst & Young (EY)",
    period: "Mar 2021 — Feb 2022",
    description:
      "Built 0-to-1 AI-powered B2C product for digital banking, increasing market penetration by 15% and customer satisfaction by 35%.",
    current: false,
  },
  {
    role: "Associate Product Manager",
    company: "Larsen & Toubro (L&T)",
    period: "May 2019 — Mar 2021",
    description:
      "Led smart city initiative with IoT-based solutions, securing contracts worth $5M through strategic business development.",
    current: false,
  },
  {
    role: "Product Analyst",
    company: "ADP Pvt. Ltd.",
    period: "Mar 2015 — Jun 2017",
    description:
      "Spearheaded Tax Credits Services product, improving data processing speed by 50% and reducing report generation time by 60%.",
    current: false,
  },
]

const education = [
  {
    degree: "AI & Business Strategies",
    institution: "UC Berkeley",
    period: "2022",
  },
  {
    degree: "MBA",
    institution: "IIM Kozhikode",
    period: "2017 — 2019",
  },
  {
    degree: "B.Tech",
    institution: "JNTU",
    period: "2010 — 2014",
  },
]

export function ExperienceSection() {
  return (
    <section id="experience" className="py-20 px-6 bg-muted/50">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Career Journey</p>
          <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground">Experience</h2>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-0 lg:left-1/2 top-0 bottom-0 w-px bg-border transform lg:-translate-x-1/2" />

          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div
                key={exp.company}
                className={`relative flex flex-col lg:flex-row gap-8 ${
                  index % 2 === 0 ? "lg:flex-row" : "lg:flex-row-reverse"
                }`}
              >
                {/* Timeline Dot */}
                <div className="absolute left-0 lg:left-1/2 w-4 h-4 rounded-full bg-primary transform lg:-translate-x-1/2 -translate-x-1/2 top-8 lg:top-6 z-10 ring-4 ring-background" />

                {/* Content Card */}
                <div className={`lg:w-1/2 ${index % 2 === 0 ? "lg:pr-12" : "lg:pl-12"} pl-8 lg:pl-0`}>
                  <div
                    className={`bg-card border border-border rounded-lg p-6 hover:shadow-md transition-shadow ${
                      exp.current ? "border-primary/30" : ""
                    }`}
                  >
                    {exp.current && (
                      <span className="inline-block px-3 py-1 bg-primary/10 text-primary text-xs font-semibold rounded mb-3">
                        Current
                      </span>
                    )}
                    <h3 className="text-xl font-semibold text-foreground mb-1">{exp.role}</h3>
                    <p className="text-primary font-semibold mb-2">{exp.company}</p>
                    <p className="text-sm text-muted-foreground mb-3">{exp.period}</p>
                    <p className="text-muted-foreground text-sm">{exp.description}</p>
                  </div>
                </div>

                {/* Empty space for alternating layout */}
                <div className="hidden lg:block lg:w-1/2" />
              </div>
            ))}
          </div>
        </div>

        <div className="mt-20">
          <div className="text-center mb-12">
            <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Academic Background</p>
            <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground">Education</h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {education.map((edu) => (
              <div
                key={edu.institution}
                className="bg-card border border-border rounded-lg p-6 text-center hover:shadow-md transition-shadow"
              >
                <h3 className="text-lg font-semibold text-foreground mb-1">{edu.degree}</h3>
                <p className="text-primary font-medium mb-2">{edu.institution}</p>
                <p className="text-sm text-muted-foreground">{edu.period}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
