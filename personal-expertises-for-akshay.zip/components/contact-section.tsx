import { Calendar, ArrowRight } from "lucide-react"
import { ContactForm } from "./contact-form"
import { NewsletterForm } from "./newsletter-form"
import { BookingForm } from "./booking-form"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export function ContactSection() {
  return (
    <section id="contact" className="py-20 px-6 bg-muted/50">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <p className="text-primary font-medium tracking-widest uppercase text-xs mb-2">Get Started</p>
          <h2 className="text-3xl lg:text-4xl font-serif font-semibold text-foreground mb-4">
            Ready to Transform Your Career?
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Book a free trial session to discuss your goals and create a personalized plan for your success.
          </p>
        </div>

        <Tabs defaultValue="booking" className="mb-12">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="booking">Book Session</TabsTrigger>
            <TabsTrigger value="contact">Send Message</TabsTrigger>
            <TabsTrigger value="newsletter">Stay Updated</TabsTrigger>
          </TabsList>

          <TabsContent value="booking">
            <BookingForm />
          </TabsContent>

          <TabsContent value="contact">
            <ContactForm />
          </TabsContent>

          <TabsContent value="newsletter">
            <div className="bg-card border border-border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-foreground mb-2">Subscribe to My Newsletter</h3>
              <p className="text-muted-foreground text-sm mb-4">
                Get insights on product management, AI/ML, career growth, and exclusive mentorship tips delivered to
                your inbox.
              </p>
              <NewsletterForm />
            </div>
          </TabsContent>
        </Tabs>

        {/* Quick booking CTA */}
        <div className="text-center mb-12">
          <p className="text-sm text-muted-foreground mb-4">Prefer to book directly?</p>
          <a
            href="https://cal.com/akkshay-sharma/15min"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md font-medium hover:bg-primary/90 transition-colors"
          >
            <Calendar size={18} />
            Book Free 15-min Trial on Cal.com
            <ArrowRight size={16} />
          </a>
        </div>

        {/* Mentorship promise */}
        <div className="bg-card border border-border rounded-lg p-8">
          <h3 className="text-lg font-semibold text-foreground mb-6 text-center">The Mentorship Promise</h3>
          <div className="grid sm:grid-cols-3 gap-6 text-sm">
            <div className="text-center">
              <p className="text-primary font-semibold mb-1">Vetted & Verified</p>
              <p className="text-muted-foreground">Exclusive mentor with proven track record</p>
            </div>
            <div className="text-center">
              <p className="text-primary font-semibold mb-1">Money Back</p>
              <p className="text-muted-foreground">100% refund in 7 days if not satisfied</p>
            </div>
            <div className="text-center">
              <p className="text-primary font-semibold mb-1">Flexibility</p>
              <p className="text-muted-foreground">Change mentors at zero additional cost</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} Akkshay Sharma. All rights reserved.
          </p>
        </div>
      </div>
    </section>
  )
}
