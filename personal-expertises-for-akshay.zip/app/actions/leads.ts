"use server"

import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const supabase = supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null

function checkSupabaseConfig() {
  if (!supabase) {
    return {
      success: false,
      error:
        "Database not configured. Please add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY environment variables.",
    }
  }
  return null
}

export async function submitContactForm(formData: FormData) {
  const configError = checkSupabaseConfig()
  if (configError) return configError

  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string
  const message = formData.get("message") as string

  if (!name || !email || !message) {
    return { success: false, error: "Please fill in all required fields" }
  }

  const { error } = await supabase!.from("contact_submissions").insert({
    name,
    email,
    phone: phone || null,
    message,
  })

  if (error) {
    console.error("Contact form error:", error)
    return { success: false, error: "Failed to submit. Please try again." }
  }

  return { success: true }
}

export async function subscribeNewsletter(formData: FormData) {
  const configError = checkSupabaseConfig()
  if (configError) return configError

  const email = formData.get("email") as string
  const name = formData.get("name") as string

  if (!email) {
    return { success: false, error: "Please provide your email" }
  }

  const { error } = await supabase!.from("newsletter_signups").insert({
    email,
    name: name || null,
    source: "website",
  })

  if (error) {
    if (error.code === "23505") {
      return { success: false, error: "You're already subscribed!" }
    }
    console.error("Newsletter signup error:", error)
    return { success: false, error: "Failed to subscribe. Please try again." }
  }

  return { success: true }
}

export async function submitBookingRequest(formData: FormData) {
  const configError = checkSupabaseConfig()
  if (configError) return configError

  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const phone = formData.get("phone") as string
  const interest = formData.get("interest") as string
  const experienceLevel = formData.get("experience_level") as string
  const message = formData.get("message") as string

  if (!name || !email) {
    return { success: false, error: "Please fill in all required fields" }
  }

  const { error } = await supabase!.from("booking_requests").insert({
    name,
    email,
    phone: phone || null,
    interest: interest || null,
    experience_level: experienceLevel || null,
    message: message || null,
    status: "pending",
  })

  if (error) {
    console.error("Booking request error:", error)
    return { success: false, error: "Failed to submit. Please try again." }
  }

  return { success: true }
}
