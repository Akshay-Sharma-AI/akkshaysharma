import { createClient, type SupabaseClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

export const supabase: SupabaseClient | null =
  supabaseUrl && supabaseAnonKey ? createClient(supabaseUrl, supabaseAnonKey) : null

export const isSupabaseConfigured = !!supabase

// Types for our tables
export interface ContactSubmission {
  id?: string
  name: string
  email: string
  phone?: string
  message: string
  created_at?: string
}

export interface NewsletterSignup {
  id?: string
  email: string
  name?: string
  source?: string
  subscribed_at?: string
}

export interface BookingRequest {
  id?: string
  name: string
  email: string
  phone?: string
  interest?: string
  experience_level?: string
  message?: string
  status?: string
  created_at?: string
}
